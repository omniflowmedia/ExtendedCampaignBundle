<?php

declare(strict_types=1);

namespace MauticPlugin\SurgeExtendedCampaignBundle\Entity;

use Mautic\CoreBundle\Entity\CommonRepository;

class CustomCampaignRepository extends CommonRepository
{
    
}
