<?php

declare(strict_types=1);

namespace MauticPlugin\SurgeExtendedCampaignBundle;

use Mautic\PluginBundle\Bundle\PluginBundleBase;

class SurgeExtendedCampaignBundle extends PluginBundleBase
{
}
